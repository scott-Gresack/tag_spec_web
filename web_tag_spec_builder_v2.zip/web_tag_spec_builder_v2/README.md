# web_tag_spec_builder_v2

A Pen created on CodePen.io. Original URL: [https://codepen.io/scott-gresack/pen/xbKRyQB](https://codepen.io/scott-gresack/pen/xbKRyQB).

