new Vue({
  el: "#app",
  data: {
    showInstructions: true,
    eventType: "utag.view()", // Default event type
    keyValuePairs: [] // Array of key-value pairs
  },
  computed: {
    formattedSnippet() {
      if (this.keyValuePairs.length === 0) return `${this.eventType}({});`;

      const payload = this.keyValuePairs.reduce((acc, pair) => {
        if (pair.key.trim() && pair.value.trim()) acc[pair.key] = pair.value;
        return acc;
      }, {});

      return `${this.eventType}(${JSON.stringify(payload, null, 2)});`;
    },
    xdmObject() {
      const xdmTemplate = {
        xdm: {
          _experience: {
            analytics: {
              customDimensions: { eVars: {}, props: {} }
            }
          }
        }
      };

      // Create dynamic event ranges
      for (let i = 1; i <= 900; i += 100) {
        const range = `event${i}to${i + 99}`;
        xdmTemplate.xdm._experience.analytics[range] = {};
      }

      this.keyValuePairs.forEach((pair) => {
        const keyType = this.getKeyType(pair.analyticsKey);

        if (keyType === "events") {
          const eventNum = parseInt(pair.analyticsKey.replace("event", ""), 10);
          const range = `event${Math.floor((eventNum - 1) / 100) * 100 + 1}to${
            Math.ceil(eventNum / 100) * 100
          }`;
          xdmTemplate.xdm._experience.analytics[range][pair.analyticsKey] = {
            value: pair.value
          };
        } else if (keyType) {
          xdmTemplate.xdm._experience.analytics.customDimensions[keyType][
            pair.analyticsKey
          ] = pair.value;
        }
      });

      return JSON.stringify(xdmTemplate, null, 2);
    }
  },
  methods: {
    toggleInstructions() {
      this.showInstructions = !this.showInstructions;
    },
    setEventType(type) {
      this.eventType = type;
    },
    addKeyValuePair() {
      this.keyValuePairs.push({ key: "", value: "", analyticsKey: "" });
    },
    removeKeyValuePair(index) {
      this.keyValuePairs.splice(index, 1);
    },
    copyToClipboard(content) {
      navigator.clipboard.writeText(content).then(
        () => alert("Copied to clipboard! 🎉"),
        () => alert("Failed to copy content.")
      );
    },
    getKeyType(analyticsKey) {
      if (/^evar\d+$/i.test(analyticsKey)) return "eVars";
      if (/^prop\d+$/i.test(analyticsKey)) return "props";
      if (/^event\d+$/i.test(analyticsKey)) return "events";
      return null;
    }
  }
});
